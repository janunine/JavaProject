/**
 * A driver program that generate 10 numbers using a Poisson distribution
 * with a specified mean value
 * 
 * @author  COSC 311, Fall '22
 * @version (10-13-22)
 */


package TestPoisson;

import java.util.*;

public class Test {
	public static void main(String [] args)
	{
		Scanner keyIn = new Scanner(System.in);
		System.out.print("Enter the average time between dial in attempt: ");
		double lambda = keyIn.nextDouble();
		Poisson gen = new Poisson (1/lambda);
		for (int i=0; i<10; i++)
			System.out.print(gen.nextInt()+"  ");
			
		System.out.print("\nEnter the average connection time: ");
		double lambda1 = keyIn.nextDouble();
		Poisson gen1 = new Poisson (lambda1);
		for (int i=0; i<10; i++)
			System.out.print(gen1.nextInt()+"  ");
	}
}
